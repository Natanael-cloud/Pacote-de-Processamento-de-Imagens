def main():
    print("Image processing package is running!")
